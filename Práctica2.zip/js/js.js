window.onload = inicio;

function inicio() {
    document.formulario.onsubmit = validar;
}

function validar() {
    let enviar = true;
    
	// Mensaje de error inicial
	document.formulario.nombreInvalido.value = "";
	document.formulario.apellidoInvalido.value = "";
	document.formulario.nifInvalido.value = "";
    document.formulario.fechaInvalida.value = "";
	document.formulario.tipoViaInvalido.value = "";
    document.formulario.denominacionViaInvalida.value = "";
    document.formulario.numeroInvalido.value = "";
    document.formulario.correoInvalido.value = "";
    document.formulario.webInvalida.value = "";
    document.formulario.estadoCivilInvalido.value = "";
    document.formulario.sectorestrabajadosInvalidos.value = "";
    document.formulario.paisesInvalidos.value = "";
    
	// Obtenemos y limpiamos los datos introducidos en el formulario
    let nombre = document.formulario.nombre.value.trim();
    let apellidos = document.formulario.apellidos.value.trim();
	let nif = document.formulario.nif.value.trim();
	let fechaNacimiento = document.formulario.fechaNacimiento.value.trim();
	let tipoVia = document.formulario.tipoVia.value.trim();
    let denominacionVia = document.formulario.denominacionVia.value.trim();
	let numero = document.formulario.numero.value.trim();
    let correo = document.formulario.correo.value.trim();
    let web = document.formulario.web.value.trim();
    let estadoCivil = document.formulario.estadoCivil.value;
    let sector = document.formulario.sector;
    let paises = document.formulario.paises;

	// Mensajes de error si la validación del campo fue incorrecta
    if (!validarNombre(nombre)) {
        enviar = false;
        document.formulario.nombreInvalido.value = "El nombre introducido no es válido.";
    }

    if (!validarApellidos(apellidos)) {
        enviar = false;
        document.formulario.apellidoInvalido.value = "Los apellidos introducidos no son válidos.";
    }

	if (!validarNif(nif)) {
        enviar = false;
        document.formulario.nifInvalido.value = "El NIF introducido no es válido.";
    }

	if (!validarFechaNacimiento(fechaNacimiento)) {
        enviar = false;
        document.formulario.fechaInvalida.value = "La fecha de nacimiento introducida no es válida.";
    }

    if (!validarTipoVia(tipoVia)) {
        enviar = false;
        document.formulario.tipoViaInvalido.value = "El tipo de vía introducido no es válido.";
    }

    if (!validarDenominacionVia(denominacionVia)) {
        enviar = false;
        document.formulario.denominacionViaInvalida.value = "La denominación de la vía introducida no es válida.";
    }

    if (!validarNumero(numero)) {
        enviar = false;
        document.formulario.numeroInvalido.value = "El número introducido no es válido.";
    }

    if (!validarCorreo(correo)) {
        enviar = false;
        document.formulario.correoInvalido.value = "El correo introducido no es válido.";
    }

    if (!validarWeb(web)) {
        enviar = false;
        document.formulario.webInvalida.value = "La página web introducida no es válida.";
    }

    if (estadoCivil.length == 0) {
        enviar = false;
        document.formulario.estadoCivilInvalido.value = "Seleccione estado civil.";
    } 
    
    if (!validarSectores(sector)) {
        enviar = false;
        document.formulario.sectorestrabajadosInvalidos.value = "Seleccione 3 sectores.";
    } 
    
    if (!validarPaises(paises)) {
        enviar = false;
        document.formulario.paisesInvalidos.value = "Seleccione 2 países.";
    } 
    
    return enviar;

}

// Validación del campo Nombre
function validarNombre(valor) {
    valor = valor.toLowerCase();
    let valido = true;
    let expresionRegular = /^[a-záéíóúñ]{2}[a-záéíóúñ ]{0,14}[a-záéíóúñ]$/i;
    if (!expresionRegular.test(valor)) {
        valido = false;
    }
    return valido;
}

// Validación del campo Apellidos
function validarApellidos(valor) {
    valor = valor.toLowerCase();
    let valido = true;
    let expresionRegular = /^[a-záéíóúñ]{5}[a-záéíóúñ\- ]{1,28}[a-záéíóúñ]{3}$/i;
    if (!expresionRegular.test(valor)) {
        valido = false;
    }
    return valido;
}

// Validación del campo NIF
function validarNif(valor) {
    valor = valor.toLowerCase();
    let valido = true;
    let expresionRegular = /^[0-9XYZKLM][0-9]{7}[TRWAGMYFPDXBNJZSQVHLCKE]$/i;
    if (!expresionRegular.test(valor)) {
        valido = false;
    }
    return valido;
}

// Validación del campo Fecha Nacimiento
function validarFechaNacimiento(valor) {
    valor = valor.toLowerCase();
    let valido = true;
    let expresionRegular = /^((((((0?[1-9])|([12]\d)|(3[01]))[\-\/]((0?[13578])|(1[02])))|(((0?[1-9])|([12]\d)|(30))[\-\/]((0?[469])|(11))))[\-\/]\d{4}))|((((0?[1-9])|[12]\d))[\-\/]0?2[\-\/](([02468][048]00)|([13579][26]00)|(\d\d[2468][048])|(\d\d[13579][26])|(\d\d0[48]))|(((0?[1-9])|(1\d)|(2[-8]))[\-\/]0?2(([02468][1235679]00)|([13579][01345789]00)|(\d\d[02468][1235679])|(\d\d[13579][01345789]))))$/;
    if (!expresionRegular.test(valor)) {
        valido = false;
    }
    return valido;
}

// Validación del campo Tipo Via
function validarTipoVia(valor) {
    valor = valor.toLowerCase();
    let valido = true;
    let expresionRegular = /^\b((Calle)|(Avenida)|(Paseo)|(Plaza)|(Camino)|(Ronda)|(Carretera)|(Plazuela))\b$/i;
    if (!expresionRegular.test(valor)) {
        valido = false;
    }
    return valido;
}

// Validación del campo Denominación Via
function validarDenominacionVia(valor) {
    valor = valor.toLowerCase();
    let valido = true;
    let expresionRegular = /^[a-záéíóúñ][a-záéíóúñºª\-\_ ]{10,}[a-záéíóúñ]$/i;
    if (!expresionRegular.test(valor)) {
        valido = false;
    }
    return valido;
}

// Validación del campo Número
function validarNumero(valor) {
    let valido = true;
    let expresionRegular = /^[0-9]{1,3}$/;
    if (!expresionRegular.test(valor)) {
        valido = false;
    }
    return valido;
}

// Validación del campo Correo
function validarCorreo(valor) {
    valor = valor.toLowerCase();
    let valido = true;
    let expresionRegular = /^[0-9a-z\.]{6,20}@[0-9a-z]{6,20}[\.][0-9a-z]{2,4}$/i;
    if (!expresionRegular.test(valor)) {
        valido = false;
    }
    return valido;
}

// Validación del campo Web
function validarWeb(valor) {
    valor = valor.toLowerCase();
    let valido = true;
    let expresionRegular = /^[0-9a-z\-\_\%\$\&\/\:]+[\.][0-9a-z]{2,4}$/i;
    if (!expresionRegular.test(valor)) {
        valido = false;
    }
    return valido;
}

// Validación del campo Sectores
function validarSectores(valor) {
    let valido = true;
    let i = 0;
    let contador = 0;
    while (i < valor.length) {
        if (valor[i].checked)
            contador++;
        i++;        
    }
    if (contador < 3) {
        valido = false;
    }
    return valido;
}

// Validación del campo Paises
function validarPaises(valor) {
    let valido = true;
    let i = 0;
    let contador = 0;
    while (i < valor.length) {
        if (valor[i].selected)
            contador++;
        i++;        
    }
    if (contador < 2) {
        valido = false;
    }
    return valido;
}
